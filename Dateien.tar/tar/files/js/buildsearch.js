function getVote(myElement){

	// count voteing up
	// chance icon to glow normal
	// send ajax request
	
	// need span and img object
	// 

}