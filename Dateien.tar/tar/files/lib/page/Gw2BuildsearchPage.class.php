<?php
namespace wcf\page;
use wcf\system\WCF;

/**
 * Shows the test page used to demonstrate the package system of WCF.
 * 
 * @author  YOUR NAME
 * @license GNU Lesser General Public License <http://opensource.org/licenses/lgpl-license.php>
 * @package com.example.package
 * @subpackage  page
 */
class Gw2BuildsearchPage extends AbstractPage {
    protected $world = '';

    public function readData() {
        parent::readData();

        $this->world = 'world';
    }

    public function assignVariables() {
        parent::assignVariables();

        WCF::getTPL()->assign(array(
            'world' => $this->world
        ));
    }
}