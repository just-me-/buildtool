INSERT INTO eso_buildsearch_builds (spielbereich, buildauslegung, klasse, waffenset, waffensetoff, titel, beschreibung, link, autor, erstellungsdatum)
	VALUES 
		('AvA', 'Schaden', 'Drachenritter', 'Bogen', 'Zweihänder', 'TitelBeschreibung1', 'Das ist eine sehr lange Buildbeschreibung1', 'www.google.ch', 'Hans Peter', '13.09.2012'), 
		('PvE', 'Heilung', 'Zauberer', 'Zweihänder', 'Bogen', 'TitelBeschreibung2', 'Das ist eine sehr lange Buildbeschreibung2', 'www.google.ch', 'Hans Muster', '14.12.2012'), 
		('Bi-Auslegung', 'Support/Tank', 'Templer', 'Zweihänder', 'Bogen', 'TitelBeschreibung3', 'Das ist eine sehr lange Buildbeschreibung3', 'www.google.ch', 'Muster Peter', '15.11.2013');
