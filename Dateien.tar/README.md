buildtool
=========

Addon fürs WoltLab Burning Board Version 4.

Die Version 3.1 ist produktiv im Einsatz unter [http://abaddons-mund.eu](http://abaddons-mund.eu/index.php?page=Gw2Buildsearch&s=95e43760aadb1c61d3984fdf95925c17c2fab55f)

