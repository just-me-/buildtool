buildtool
=========

Addon fürs WoltLab Burning Board Version 4.

Die Version 4.1 ist produktiv im Einsatz unter [http://gilde-legendary.de](http://www.gilde-legendary.de)

