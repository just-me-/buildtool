buildtool
=========

Addon fürs WoltLab Burning Board Version 4.

Die Version 1.0.35 ist produktiv im Einsatz unter [http://gilde-legendary.de](http://www.gilde-legendary.de/index.php/EsoBuildsearch/)

